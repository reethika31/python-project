from django.apps import AppConfig


class TtpConfig(AppConfig):
    name = 'TTP'
